def show():
    for i in range(3):
        for j in range(3):
            print(game[i][j], end=' ')
        print()


game = [['-', '-', '-'],
        ['-', '-', '-'],
        ['-', '-', '-']]

show()

while True:
    # player 1
    while True:
        row = int(input())
        col = int(input())
        if 0 <= row <= 2 and 0 <= col <= 2:
            game[row][col] = 'X'
            break
        else:
            print('index out of range! try again')
    show()
# player2
    while True:
        row = int(input())
        col = int(input())

        if 0 <= row <= 2 and 0 <= col <= 2:
            game[row][col] = 'O'
            break
        else:
            print('index out of range! try again')
    show()
