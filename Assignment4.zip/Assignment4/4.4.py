import math

def delta(a,b,c,d):

    w=18*a*b*c*d-4*b**3*d+b**2*c**2-4*a*c**3-27*a**2*d**2

    return w

a = float (input())
b = float (input())
c = float (input())
d = float (input())

u1=1
u2=(complex(-1,math.sqrt(3)))/2
u3=(complex(-1,-1*math.sqrt(3)))/2

w0=b**2-3*a*c
w1=2*b**3-9*a*b*c+27*a**2*d
big_c= ((w1+math.sqrt(-27*a**2*delta(a,b,c,d)))/2)**(1/3)


x1= (-1/(3*a))*(b+u1*big_c+w0/(u1*big_c))
x2= (-1/(3*a))*(b+u2*big_c+w0/(u2*big_c))
x3= (-1/(3*a))*(b+u3*big_c+w0/(u3*big_c))

print("x1=",x1)
print("x2=",x2)
print("x3=",x3)
